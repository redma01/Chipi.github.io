// ... existing code ...
    profileMenu?.addEventListener && profileMenu.addEventListener('keydown', (e) => {
      const { key } = e;
      if (key === 'Enter' || key === ' ') {
        const el = document.activeElement;
        if (el && el.getAttribute && el.getAttribute('role') === 'menuitem') el.click();
      }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Modal functionality
    const lessonPlanningModal = document.getElementById('lessonPlanningModal');
    const assessmentCreationModal = document.getElementById('assessmentCreationModal');

    const lessonPlanForm = document.getElementById('lessonPlanForm');
    const assessmentCreationForm = document.getElementById('assessmentCreationForm');

    // Use event delegation for buttons that might be added dynamically
    document.body.addEventListener('click', function(event) {
        if (event.target.matches('#lessonPlanningBtn')) {
            lessonPlanningModal.style.display = 'block';
        }
        if (event.target.matches('#assessmentBtn')) {
            assessmentCreationModal.style.display = 'block';
        }
    });

    // Close modals
    const closeButtons = document.querySelectorAll('.close-btn');
    closeButtons.forEach(button => {
        button.addEventListener('click', function() {
            lessonPlanningModal.style.display = 'none';
            assessmentCreationModal.style.display = 'none';
        });
    });

    window.addEventListener('click', function(event) {
        if (event.target == lessonPlanningModal) {
            lessonPlanningModal.style.display = 'none';
        }
        if (event.target == assessmentCreationModal) {
            assessmentCreationModal.style.display = 'none';
        }
    });

    // Handle form submissions
    lessonPlanForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const subject = document.getElementById('subject').value;
        const grade = document.getElementById('gradeLevel').value;
        const topic = document.getElementById('lesson').value;
        const quarter = document.getElementById('quarter').value;

        const prompt = `Create a lesson plan for a Grade ${grade} ${subject} class. The topic is "${topic}" for the ${quarter} quarter.`;
        
        document.getElementById('userInput').value = prompt;
        sendMessage();
        lessonPlanningModal.style.display = 'none';
    });

    assessmentCreationForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const subject = document.getElementById('assessmentSubject').value;
        const grade = document.getElementById('assessmentGradeLevel').value;
        const topic = document.getElementById('assessmentTopic').value;
        const numQuestions = document.getElementById('assessmentItems').value;
        const questionType = document.getElementById('assessmentType').value;

        const prompt = `Create an assessment for a Grade ${grade} ${subject} class on the topic of "${topic}". It should have ${numQuestions} questions of the type: ${questionType}.`;
        
        document.getElementById('userInput').value = prompt;
        sendMessage();
        assessmentCreationModal.style.display = 'none';
    });
});

// ===== DEBUG HELPERS =====
// Show runtime errors and unhandled rejections as toasts and console output
function reportRuntimeError(message, detail) {
// ... existing code ...