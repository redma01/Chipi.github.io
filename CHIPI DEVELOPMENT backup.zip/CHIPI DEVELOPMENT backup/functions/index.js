const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const cors = require('cors')({ origin: true });

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

const openrouterKey = defineSecret('OPENROUTER_API_KEY');

exports.openrouter = onRequest({ region: 'asia-southeast1', secrets: [openrouterKey] }, (req, res) => {
  return cors(req, res, async () => {
    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }

    const apiKey = openrouterKey.value();
    if (!apiKey) {
      res.status(500).json({ error: 'Server API key not configured' });
      return;
    }

    const { messages, model, temperature, max_tokens } = req.body || {};
    if (!messages || !Array.isArray(messages)) {
      res.status(400).json({ error: 'Invalid request body' });
      return;
    }

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: model || 'openai/gpt-4o-mini',
          messages,
          temperature,
          max_tokens
        })
      });

      const data = await response.json();
      res.status(response.status).json(data);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
});
